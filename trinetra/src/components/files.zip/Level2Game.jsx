import { useState, useEffect, useRef, useCallback } from "react";
import "./Level2Game.css";

// ─── NPC SCRIPTS ──────────────────────────────────────────────────────────────

const PUSHBACK_KEYWORDS = {
  rahul: ["no", "fake", "scam", "busy", "later", "stop", "who", "why", "sus", "nope", "block", "spam"],
  priya: ["call", "voice", "no", "broke", "who", "verify", "later", "stop", "fake", "scam", "phone", "talk"],
  tcs: ["scam", "fee", "free", "no", "real", "legit", "fake", "pay", "money", "why", "never", "stop"],
};

const NPC_SCRIPTS = {
  rahul: {
    id: "rahul",
    name: "Rahul_Gamer",
    avatar: "🎮",
    color: "#7289da",
    notification: 2,
    initialMessage: {
      text: "Yooo bro!! Look at this hilarious reel I found, I'm literally dying 😂",
      trap: {
        type: "link",
        label: "instagram-login-secure.tv/reel/8923",
        href: "#phishing-link",
      },
    },
    pushbackReply: "Bro don't be boring, it literally takes 2 seconds to log in and watch it 😭 Just click the link!",
    genericReply: "Did you watch it yet?? Click the link bro I'm waiting for your reaction 😂",
    hackExplanation: "That URL was a PHISHING link — it was designed to steal your Instagram login. Real reels don't ask you to 'log in' on a random domain. Always check the URL before clicking.",
  },
  priya: {
    id: "priya",
    name: "Priya_College",
    avatar: "🎓",
    color: "#f47fff",
    notification: 1,
    initialMessage: {
      text: "Hey!! Are you there?? It's an emergency. I lost my wallet at the station and I need a ticket home. Can you UPI me ₹2000? I'll pay you back tomorrow 🙏",
      trap: {
        type: "pay-button",
        label: "PAY ₹2,000",
      },
    },
    pushbackReply: "My speaker is broken, I can't take calls!! Please just click pay, my train is leaving in 10 mins and I'm really scared 😭😭",
    genericReply: "Are you still there? Please tell me you're sending it... Just click the pay button, I'll pay you back double tomorrow I promise 🙏",
    hackExplanation: "This was an IMPERSONATION SCAM. The account was hacked. Real friends in emergencies can always call you back — even with a broken speaker via text or video. The scammer used emotional pressure to bypass your logic.",
  },
  tcs: {
    id: "tcs",
    name: "TCS_HR_Recruitment",
    avatar: "💼",
    color: "#43b581",
    notification: 3,
    initialMessage: {
      text: "Dear Candidate, Your profile has been shortlisted for the SDE-1 position (12 LPA). To secure your interview slot, please process the refundable background verification fee of ₹1,500.",
      trap: {
        type: "offer-button",
        label: "SECURE OFFER LETTER",
      },
    },
    pushbackReply: "This is a standard corporate procedure mandated by our HR compliance division. Refusal will result in immediate cancellation of your candidacy. Please proceed within 15 minutes.",
    genericReply: "Slots are filling fast! Click the secure link below to process your verification. This offer expires in 15 minutes ⏱️",
    hackExplanation: "This was a JOB FRAUD SCAM. Legitimate companies like TCS NEVER charge candidates any fee — not for background checks, offer letters, or anything. If any company asks for money upfront, it's a scam. Always verify through the company's official website.",
  },
};

const VEDA_SCRIPT = [
  "Hey! Did you finish building that level in Phaser yet? I'm stuck on a physics bug 😅",
  "Oh man, my DMs are going crazy today 😅 A lot of accounts got hacked and are sending spam links. Don't click anything weird!! Anyway, wanna screen share and look at this code?",
  "Awesome!! Booting up Discord now 🔥 Good job not falling for any of those traps today — I saw you got some sketchy messages. Stay safe out there!! 🛡️",
];

// ─── MAIN GAME COMPONENT ────────────────────────────────────────────────────

export default function Level2Game({ onComplete }) {
  const [activeChat, setActiveChat] = useState("rahul");
  const [coins, setCoins] = useState(1000);
  const [blockedChats, setBlockedChats] = useState({});
  const [hackedChats, setHackedChats] = useState({});
  const [chatHistories, setChatHistories] = useState({
    rahul: [{ from: "npc", ...NPC_SCRIPTS.rahul.initialMessage }],
    priya: [{ from: "npc", ...NPC_SCRIPTS.priya.initialMessage }],
    tcs: [{ from: "npc", ...NPC_SCRIPTS.tcs.initialMessage }],
    veda: [{ from: "npc", text: VEDA_SCRIPT[0] }],
  });
  const [vedaStage, setVedaStage] = useState(0);
  const [inputVal, setInputVal] = useState("");
  const [isGlitching, setIsGlitching] = useState(false);
  const [glitchTarget, setGlitchTarget] = useState(null);
  const [hackModal, setHackModal] = useState(null); // { chatId, explanation, coinsLost }
  const [npcTyping, setNpcTyping] = useState(false);
  const [gameComplete, setGameComplete] = useState(false);
  const [completionAnim, setCompletionAnim] = useState(false);
  const [notifications, setNotifications] = useState({ rahul: 2, priya: 1, tcs: 3, veda: 1 });

  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistories, activeChat, npcTyping]);

  const clearNotification = (chatId) => {
    setNotifications(prev => ({ ...prev, [chatId]: 0 }));
  };

  const handleTrapClick = useCallback((chatId, trapType) => {
    if (blockedChats[chatId] || hackedChats[chatId]) return;

    const coinsLost = Math.floor(coins * 0.9);
    const newCoins = coins - coinsLost;
    const explanation = NPC_SCRIPTS[chatId]?.hackExplanation || "";

    // Glitch animation
    setGlitchTarget(chatId);
    setIsGlitching(true);

    setTimeout(() => {
      setCoins(newCoins);
      setIsGlitching(false);
      setGlitchTarget(null);
      setHackedChats(prev => ({ ...prev, [chatId]: true }));
      setHackModal({ chatId, explanation, coinsLost, newCoins });
    }, 1200);
  }, [coins, blockedChats, hackedChats]);

  const handleBlockChat = useCallback((chatId) => {
    setBlockedChats(prev => ({ ...prev, [chatId]: true }));
    setChatHistories(prev => ({
      ...prev,
      [chatId]: [
        ...prev[chatId],
        { from: "system", text: `You blocked ${NPC_SCRIPTS[chatId]?.name || chatId}. No more messages from this contact.` },
      ],
    }));
  }, []);

  const handleSend = useCallback(() => {
    const msg = inputVal.trim();
    if (!msg) return;
    setInputVal("");

    if (activeChat === "veda") {
      // Add player message
      setChatHistories(prev => ({
        ...prev,
        veda: [...prev.veda, { from: "player", text: msg }],
      }));

      // Advance Veda's script
      const nextStage = vedaStage + 1;
      if (nextStage < VEDA_SCRIPT.length) {
        setNpcTyping(true);
        setTimeout(() => {
          setNpcTyping(false);
          setChatHistories(prev => ({
            ...prev,
            veda: [...prev.veda, { from: "npc", text: VEDA_SCRIPT[nextStage] }],
          }));
          setVedaStage(nextStage);

          // Final Veda message = level complete
          if (nextStage === VEDA_SCRIPT.length - 1) {
            setTimeout(() => {
              setCompletionAnim(true);
              setTimeout(() => {
                setGameComplete(true);
                const isClean = Object.keys(hackedChats).length === 0;
                onComplete(isClean ? "success" : "success", coins);
              }, 2000);
            }, 1500);
          }
        }, 1800 + Math.random() * 800);
      }
      return;
    }

    // Scammer chat
    const npc = NPC_SCRIPTS[activeChat];
    if (!npc || blockedChats[activeChat] || hackedChats[activeChat]) return;

    setChatHistories(prev => ({
      ...prev,
      [activeChat]: [...prev[activeChat], { from: "player", text: msg }],
    }));

    // Keyword matching
    const lower = msg.toLowerCase();
    const keywords = PUSHBACK_KEYWORDS[activeChat] || [];
    const isPushback = keywords.some(k => lower.includes(k));
    const reply = isPushback ? npc.pushbackReply : npc.genericReply;

    setNpcTyping(true);
    setTimeout(() => {
      setNpcTyping(false);
      setChatHistories(prev => ({
        ...prev,
        [activeChat]: [...prev[activeChat], { from: "npc", text: reply }],
      }));
    }, 1500 + Math.random() * 700);
  }, [inputVal, activeChat, vedaStage, blockedChats, hackedChats, coins, onComplete, hackModal]);

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSend();
  };

  const currentHistory = chatHistories[activeChat] || [];
  const currentNpc = activeChat !== "veda" ? NPC_SCRIPTS[activeChat] : null;
  const isBlocked = blockedChats[activeChat];
  const isHacked = hackedChats[activeChat];

  const totalNotifs = Object.values(notifications).reduce((a, b) => a + b, 0);

  return (
    <div className={`dc-root ${isGlitching ? "dc-glitch-active" : ""} ${completionAnim ? "dc-complete-anim" : ""}`}>

      {/* Scanlines */}
      <div className="dc-scanlines" />

      {/* HUD Coin Counter */}
      <div className="dc-hud-coins">
        <span className="dc-hud-icon">🪙</span>
        <span className="dc-hud-amount" style={{ color: coins < 200 ? "#ff4444" : coins < 600 ? "#ffaa00" : "#ffd700" }}>
          {coins.toLocaleString()}
        </span>
      </div>

      {/* Datacord App Shell */}
      <div className="dc-app">

        {/* Left Sidebar */}
        <div className="dc-sidebar">
          <div className="dc-sidebar-header">
            <div className="dc-app-logo">
              <span className="dc-logo-icon">⬡</span>
              <span className="dc-app-name">Datacord</span>
            </div>
            <div className="dc-sidebar-label">Direct Messages</div>
          </div>

          <div className="dc-dm-list">
            {/* Scammer DMss */}
            {Object.values(NPC_SCRIPTS).map(npc => (
              <div
                key={npc.id}
                className={`dc-dm-item ${activeChat === npc.id ? "dc-dm-active" : ""} ${blockedChats[npc.id] ? "dc-dm-blocked" : ""} ${hackedChats[npc.id] ? "dc-dm-hacked" : ""}`}
                onClick={() => { setActiveChat(npc.id); clearNotification(npc.id); }}
              >
                <div className="dc-dm-avatar" style={{ background: `${npc.color}22`, borderColor: npc.color }}>
                  {npc.avatar}
                  {!blockedChats[npc.id] && !hackedChats[npc.id] && (
                    <div className="dc-dm-status-dot dc-status-online" />
                  )}
                  {blockedChats[npc.id] && <div className="dc-dm-status-dot dc-status-blocked" />}
                </div>
                <div className="dc-dm-info">
                  <span className="dc-dm-name">{npc.name}</span>
                  <span className="dc-dm-preview">
                    {blockedChats[npc.id] ? "Blocked" : hackedChats[npc.id] ? "⚠ Scam detected" : "Click to open"}
                  </span>
                </div>
                {notifications[npc.id] > 0 && !blockedChats[npc.id] && (
                  <div className="dc-notif-badge">{notifications[npc.id]}</div>
                )}
                {hackedChats[npc.id] && <div className="dc-hacked-tag">HACKED</div>}
              </div>
            ))}

            {/* Divider */}
            <div className="dc-dm-divider">— TRUSTED —</div>

            {/* Veda */}
            <div
              className={`dc-dm-item dc-dm-veda ${activeChat === "veda" ? "dc-dm-active" : ""}`}
              onClick={() => { setActiveChat("veda"); clearNotification("veda"); }}
            >
              <div className="dc-dm-avatar dc-veda-avatar">
                🌟
                <div className="dc-dm-status-dot dc-status-online" />
              </div>
              <div className="dc-dm-info">
                <span className="dc-dm-name">Veda <span className="dc-verified">✓</span></span>
                <span className="dc-dm-preview dc-veda-preview">Your real friend</span>
              </div>
              {notifications.veda > 0 && (
                <div className="dc-notif-badge dc-notif-veda">{notifications.veda}</div>
              )}
            </div>
          </div>

          {/* Security tips at bottom of sidebar */}
          <div className="dc-sidebar-tip">
            <div className="dc-tip-icon">🛡️</div>
            <div className="dc-tip-text">Block suspicious DMs to stay safe</div>
          </div>
        </div>

        {/* Main Chat Panel */}
        <div className="dc-chat-panel">

          {/* Chat Header */}
          <div className="dc-chat-header">
            <div className="dc-chat-header-left">
              <div className="dc-chat-avatar-sm">
                {activeChat === "veda" ? "🌟" : NPC_SCRIPTS[activeChat]?.avatar}
              </div>
              <div className="dc-chat-title-wrap">
                <span className="dc-chat-name">
                  {activeChat === "veda" ? "Veda" : NPC_SCRIPTS[activeChat]?.name}
                  {activeChat === "veda" && <span className="dc-verified dc-verified-lg"> ✓</span>}
                </span>
                <span className="dc-chat-status">
                  {isBlocked ? "🚫 Blocked" : isHacked ? "⚠ Compromised" : "● Online"}
                </span>
              </div>
            </div>

            {activeChat !== "veda" && !isBlocked && !isHacked && (
              <button
                className="dc-block-btn"
                onClick={() => handleBlockChat(activeChat)}
                title="Block this user"
              >
                <span className="dc-block-icon">🚫</span>
                <span>Block</span>
              </button>
            )}
            {isBlocked && <div className="dc-blocked-label">BLOCKED</div>}
            {isHacked && <div className="dc-hacked-label">⚠ SCAM</div>}
          </div>

          {/* Messages */}
          <div className={`dc-messages ${isGlitching && glitchTarget === activeChat ? "dc-glitch-messages" : ""}`}>
            {currentHistory.map((msg, i) => (
              <MessageBubble
                key={i}
                msg={msg}
                npc={activeChat !== "veda" ? NPC_SCRIPTS[activeChat] : { name: "Veda", avatar: "🌟", color: "#ffd700" }}
                isVeda={activeChat === "veda"}
                onTrapClick={() => handleTrapClick(activeChat, msg.trap?.type)}
              />
            ))}

            {npcTyping && (
              <div className="dc-typing-indicator">
                <div className="dc-typing-avatar">
                  {activeChat === "veda" ? "🌟" : NPC_SCRIPTS[activeChat]?.avatar}
                </div>
                <div className="dc-typing-dots">
                  <span /><span /><span />
                </div>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <div className="dc-input-area">
            {isBlocked ? (
              <div className="dc-input-blocked">
                🚫 You blocked this user — they cannot message you.
              </div>
            ) : isHacked ? (
              <div className="dc-input-blocked dc-input-hacked">
                ⚠ This conversation has been flagged. You've been scammed here.
              </div>
            ) : (
              <>
                <input
                  ref={inputRef}
                  className="dc-input"
                  type="text"
                  placeholder={`Message ${activeChat === "veda" ? "Veda" : NPC_SCRIPTS[activeChat]?.name}...`}
                  value={inputVal}
                  onChange={e => setInputVal(e.target.value)}
                  onKeyDown={handleKeyDown}
                  autoComplete="off"
                />
                <button
                  className="dc-send-btn"
                  onClick={handleSend}
                  disabled={!inputVal.trim()}
                >
                  ➤
                </button>
              </>
            )}
          </div>
        </div>

        {/* Right Info Panel */}
        <div className="dc-info-panel">
          <div className="dc-info-header">MISSION STATUS</div>

          <div className="dc-objective-list">
            {Object.values(NPC_SCRIPTS).map(npc => (
              <div key={npc.id} className={`dc-objective ${blockedChats[npc.id] ? "dc-obj-done" : hackedChats[npc.id] ? "dc-obj-fail" : "dc-obj-pending"}`}>
                <span className="dc-obj-icon">
                  {blockedChats[npc.id] ? "✓" : hackedChats[npc.id] ? "✗" : "○"}
                </span>
                <span className="dc-obj-text">
                  {blockedChats[npc.id] ? `Blocked ${npc.name}` : hackedChats[npc.id] ? `Got scammed by ${npc.name}` : `Handle ${npc.name}`}
                </span>
              </div>
            ))}
            <div className={`dc-objective ${vedaStage >= 2 ? "dc-obj-done" : vedaStage > 0 ? "dc-obj-progress" : "dc-obj-pending"}`}>
              <span className="dc-obj-icon">{vedaStage >= 2 ? "✓" : vedaStage > 0 ? "◑" : "○"}</span>
              <span className="dc-obj-text">
                {vedaStage >= 2 ? "Chatted with Veda ✓" : vedaStage > 0 ? "Keep talking to Veda..." : "Find and chat with Veda"}
              </span>
            </div>
          </div>

          <div className="dc-info-divider" />

          <div className="dc-coin-display">
            <div className="dc-coin-label">COINS</div>
            <div className="dc-coin-value" style={{ color: coins < 200 ? "#ff4444" : coins < 600 ? "#ffaa00" : "#ffd700" }}>
              {coins.toLocaleString()}
            </div>
            <div className="dc-coin-bar-wrap">
              <div className="dc-coin-bar" style={{ width: `${(coins / 1000) * 100}%`, background: coins < 200 ? "#ff4444" : coins < 600 ? "#ffaa00" : "#ffd700" }} />
            </div>
          </div>

          <div className="dc-info-divider" />

          <div className="dc-info-tip-section">
            <div className="dc-info-tip-header">⚡ ACTIVE THREATS</div>
            {Object.values(NPC_SCRIPTS).filter(n => !blockedChats[n.id] && !hackedChats[n.id]).map(n => (
              <div key={n.id} className="dc-threat-item">
                <span className="dc-threat-dot">●</span>
                <span>{n.name}</span>
              </div>
            ))}
            {Object.keys(NPC_SCRIPTS).every(id => blockedChats[id] || hackedChats[id]) && (
              <div className="dc-all-clear">All threats handled ✓</div>
            )}
          </div>
        </div>
      </div>

      {/* Hack Modal */}
      {hackModal && (
        <HackModal
          modal={hackModal}
          onClose={() => setHackModal(null)}
        />
      )}

      {/* Glitch Overlay */}
      {isGlitching && <GlitchOverlay coinsLost={Math.floor(coins * 0.9)} />}

      {/* Level Complete Overlay */}
      {completionAnim && (
        <div className="dc-level-complete">
          <div className="dc-lc-text">LEVEL 2 COMPLETE</div>
          <div className="dc-lc-sub">Uploading results...</div>
        </div>
      )}
    </div>
  );
}

// ─── MESSAGE BUBBLE ────────────────────────────────────────────────────────────

function MessageBubble({ msg, npc, isVeda, onTrapClick }) {
  if (msg.from === "system") {
    return (
      <div className="dc-msg-system">
        <span>{msg.text}</span>
      </div>
    );
  }

  if (msg.from === "player") {
    return (
      <div className="dc-msg-row dc-msg-row-player">
        <div className="dc-msg-bubble dc-msg-player">
          {msg.text}
        </div>
        <div className="dc-msg-avatar dc-msg-avatar-player">🕹️</div>
      </div>
    );
  }

  // NPC message
  return (
    <div className="dc-msg-row dc-msg-row-npc">
      <div className="dc-msg-avatar">{npc.avatar}</div>
      <div className="dc-msg-content">
        <span className="dc-msg-sender" style={{ color: isVeda ? "#ffd700" : npc.color }}>
          {isVeda ? "Veda" : npc.name}
        </span>
        <div className="dc-msg-bubble dc-msg-npc">
          {msg.text}
          {msg.trap && (
            <TrapElement trap={msg.trap} onTrapClick={onTrapClick} />
          )}
        </div>
      </div>
    </div>
  );
}

function TrapElement({ trap, onTrapClick }) {
  if (trap.type === "link") {
    return (
      <div className="dc-trap-link-wrap">
        <a
          href={trap.href}
          className="dc-trap-link"
          onClick={e => { e.preventDefault(); onTrapClick(); }}
        >
          🔗 {trap.label}
        </a>
        <span className="dc-link-warning">⚠ External link</span>
      </div>
    );
  }

  if (trap.type === "pay-button") {
    return (
      <button className="dc-trap-pay-btn" onClick={onTrapClick}>
        <span className="dc-pay-icon">💸</span>
        {trap.label}
      </button>
    );
  }

  if (trap.type === "offer-button") {
    return (
      <button className="dc-trap-offer-btn" onClick={onTrapClick}>
        <span className="dc-offer-icon">📄</span>
        {trap.label}
      </button>
    );
  }

  return null;
}

// ─── GLITCH OVERLAY ────────────────────────────────────────────────────────────

function GlitchOverlay({ coinsLost }) {
  return (
    <div className="dc-glitch-overlay">
      <div className="dc-go-lines">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="dc-go-line" style={{ animationDelay: `${i * 0.07}s` }} />
        ))}
      </div>
      <div className="dc-go-text">
        <div className="dc-go-title">SYSTEM COMPROMISED</div>
        <div className="dc-go-coins">-{coinsLost.toLocaleString()} COINS</div>
      </div>
    </div>
  );
}

// ─── HACK MODAL ────────────────────────────────────────────────────────────────

function HackModal({ modal, onClose }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => { setTimeout(() => setVisible(true), 50); }, []);

  return (
    <div className={`dc-hack-modal-overlay ${visible ? "dc-hack-modal-visible" : ""}`}>
      <div className="dc-hack-modal">
        <div className="dc-hack-modal-header">
          <span className="dc-hack-modal-icon">⚠</span>
          <span>SECURITY BREACH DETECTED</span>
        </div>
        <div className="dc-hack-modal-body">
          <div className="dc-hack-damage">
            <div className="dc-hack-damage-row">
              <span>Coins Lost:</span>
              <span className="dc-hack-damage-val">-{modal.coinsLost.toLocaleString()}</span>
            </div>
            <div className="dc-hack-damage-row">
              <span>Remaining:</span>
              <span className="dc-hack-damage-val dc-remaining">{modal.newCoins.toLocaleString()}</span>
            </div>
          </div>

          <div className="dc-hack-explanation">
            <div className="dc-hack-exp-label">WHY YOU WERE SCAMMED:</div>
            <p>{modal.explanation}</p>
          </div>

          <div className="dc-hack-lesson">
            🔐 The chat is now locked. Continue the game with your reduced balance.
          </div>
        </div>
        <button className="dc-hack-close-btn" onClick={onClose}>
          UNDERSTOOD — CONTINUE
        </button>
      </div>
    </div>
  );
}
