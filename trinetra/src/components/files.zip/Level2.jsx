import { useState, useEffect } from "react";
import Level2Game from "./Level2Game";
import "./Level2.css";

const SUBSTAGE = {
  LANDING: "landing",
  BRIEFING: "briefing",
  GAME: "game",
  ENDING: "ending",
};

export default function Level2() {
  const [substage, setSubstage] = useState(SUBSTAGE.LANDING);
  const [gameResult, setGameResult] = useState(null);
  const [finalCoins, setFinalCoins] = useState(1000);
  const [logoAnimDone, setLogoAnimDone] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLogoAnimDone(true), 2200);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="level2-root">
      <img src="/src/assets/placeholder.png" alt="" className="level2-bg" />
      <div className="level2-overlay" />

      {substage === SUBSTAGE.LANDING && (
        <div className={`l2-logo-wrap ${logoAnimDone ? "logo-topleft" : "logo-center"}`}>
          <img src="/src/assets/Trinetra_logo.png" alt="Trinetra" className="l2-logo-img" />
        </div>
      )}

      {substage === SUBSTAGE.LANDING && logoAnimDone && (
        <div className="l2-landing-content">
          <div className="l2-level-badge">LEVEL 2</div>
          <h2 className="l2-landing-title">THE DATACORD DMs</h2>
          <p className="l2-landing-sub">Social Engineering · Phishing · Impersonation</p>
          <button className="l2-enter-btn" onClick={() => setSubstage(SUBSTAGE.BRIEFING)}>
            <span className="l2-btn-glow" />
            <span className="l2-btn-text">ENTER LEVEL 2</span>
            <span className="l2-btn-arrow">▶</span>
          </button>
        </div>
      )}

      {substage === SUBSTAGE.BRIEFING && (
        <BriefingScreen onStart={() => setSubstage(SUBSTAGE.GAME)} />
      )}

      {substage === SUBSTAGE.GAME && (
        <Level2Game
          onComplete={(result, coins) => {
            setGameResult(result);
            setFinalCoins(coins);
            setSubstage(SUBSTAGE.ENDING);
          }}
        />
      )}

      {substage === SUBSTAGE.ENDING && gameResult && (
        <EndingScreen result={gameResult} coins={finalCoins} />
      )}
    </div>
  );
}

function BriefingScreen({ onStart }) {
  const [visible, setVisible] = useState(false);
  const [typedText, setTypedText] = useState("");
  const fullText = "INCOMING THREAT SIMULATION DETECTED...";

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 60);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!visible) return;
    let i = 0;
    const interval = setInterval(() => {
      setTypedText(fullText.slice(0, i + 1));
      i++;
      if (i >= fullText.length) clearInterval(interval);
    }, 45);
    return () => clearInterval(interval);
  }, [visible]);

  return (
    <div className={`l2-briefing-overlay ${visible ? "l2-briefing-visible" : ""}`}>
      <div className="l2-briefing-card">
        <div className="l2-briefing-top-bar">
          <div className="l2-briefing-dots">
            <span className="l2-bdot l2-bdot-r" />
            <span className="l2-bdot l2-bdot-y" />
            <span className="l2-bdot l2-bdot-g" />
          </div>
          <span className="l2-briefing-title">trinetra.sys — social_engineering_sim_v2</span>
        </div>

        <div className="l2-briefing-body">
          <div className="l2-briefing-terminal-line">{typedText}<span className="l2-cursor-blink">█</span></div>

          <h2 className="l2-briefing-heading">
            <span className="l2-heading-accent">⚠</span> DATACORD INFILTRATION
          </h2>

          <div className="l2-briefing-content">
            <p className="l2-briefing-sub">
              You've been dropped into a fake messaging app called <strong>Datacord</strong>.
              Your DMs are flooded with social engineers. One of them is your real friend, Veda.
            </p>

            <div className="l2-briefing-rules">
              <div className="l2-rule-item l2-rule-danger">
                <span className="l2-rule-icon">🔗</span>
                <div>
                  <strong>Never click unknown links</strong>
                  <p>Phishing URLs steal your credentials the moment you visit them.</p>
                </div>
              </div>
              <div className="l2-rule-item l2-rule-danger">
                <span className="l2-rule-icon">💸</span>
                <div>
                  <strong>Never click unknown payment buttons</strong>
                  <p>Fake payment UIs drain your coins — 90% gone instantly.</p>
                </div>
              </div>
              <div className="l2-rule-item l2-rule-safe">
                <span className="l2-rule-icon">🚫</span>
                <div>
                  <strong>Block the scammers</strong>
                  <p>Use the block icon on suspicious DMs to silence them.</p>
                </div>
              </div>
              <div className="l2-rule-item l2-rule-safe">
                <span className="l2-rule-icon">💬</span>
                <div>
                  <strong>Talk to Veda</strong>
                  <p>Type back and forth to complete the level. She's pinned at the bottom.</p>
                </div>
              </div>
            </div>

            <div className="l2-briefing-coins">
              <span className="l2-coins-icon">🪙</span>
              <span>Starting Balance: <strong>1,000 COINS</strong></span>
            </div>
          </div>

          <button className="l2-briefing-start-btn" onClick={onStart}>
            <span className="l2-btn-glow" />
            ENTER DATACORD
          </button>
        </div>
      </div>
    </div>
  );
}

function EndingScreen({ result, coins }) {
  const [visible, setVisible] = useState(false);
  const isSuccess = result === "success";

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className={`l2-ending-overlay ${visible ? "l2-ending-visible" : ""}`}>
      <div className={`l2-ending-card ${isSuccess ? "l2-ending-success" : "l2-ending-partial"}`}>
        <div className="l2-ending-top-glow" />

        <div className="l2-ending-icon-wrap">
          <div className="l2-ending-icon">{isSuccess && coins === 1000 ? "🏆" : isSuccess ? "✓" : "⚠"}</div>
        </div>

        <h1 className="l2-ending-title">
          {isSuccess && coins === 1000
            ? "PERFECT SCORE — UNTOUCHABLE"
            : isSuccess
            ? "LEVEL COMPLETE — LESSON LEARNED"
            : "SURVIVED WITH DAMAGE"}
        </h1>

        <div className="l2-ending-stats">
          <div className="l2-stat">
            <span className="l2-stat-label">Final Coins</span>
            <span className={`l2-stat-value ${coins === 1000 ? "success" : coins > 100 ? "warn" : "failure"}`}>
              {coins.toLocaleString()} / 1000
            </span>
          </div>
          <div className="l2-stat">
            <span className="l2-stat-label">Account Status</span>
            <span className={`l2-stat-value ${isSuccess ? "success" : "warn"}`}>
              {isSuccess ? "SECURE" : "COMPROMISED"}
            </span>
          </div>
          <div className="l2-stat">
            <span className="l2-stat-label">Veda's Trust</span>
            <span className="l2-stat-value success">EARNED</span>
          </div>
        </div>

        <div className="l2-ending-lesson">
          {isSuccess ? (
            <>
              <p>
                You navigated a sea of social engineering attacks without falling for the traps that catch <strong>94% of victims</strong>.
              </p>
              <p style={{ marginTop: "12px" }}>
                Real scammers use the same techniques: fake urgency, impersonation, and emotional manipulation. The only defence is awareness — which you now have.
              </p>
            </>
          ) : (
            <>
              <p>
                You got scammed at least once. In the real world, those clicks would have drained your bank account or stolen your identity in seconds.
              </p>
              <p style={{ marginTop: "12px", color: "#ff8888" }}>
                <strong>Remember:</strong> Real links look real. Real friends don't demand money through chat. Real HR never charges fees.
              </p>
            </>
          )}
        </div>

        <div className="l2-ending-footer">
          TRINETRA — CYBERSECURITY AWARENESS TRAINING — LEVEL 2 COMPLETE
        </div>
      </div>
    </div>
  );
}
